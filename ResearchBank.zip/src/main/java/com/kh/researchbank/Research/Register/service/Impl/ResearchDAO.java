package com.kh.researchbank.Research.Register.service.Impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.kh.researchbank.common.AbstractDAO;



@Repository("researchDAO")
public class ResearchDAO extends AbstractDAO {

	
	public void store(Map<String, Object> map) {
		/* insert("research.insert",map); */
		 	
	}
}
